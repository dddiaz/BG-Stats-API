//settings.js

module.exports = {
   db: 'mongodb://diaz-bg-db-readonly:diaz-bg-db-readonlypassword@ds029605.mongolab.com:29605/heroku_233zkxnt',
   InvokeURL: 'https://uxlmtxq0vb.execute-api.us-east-1.amazonaws.com/test'
}